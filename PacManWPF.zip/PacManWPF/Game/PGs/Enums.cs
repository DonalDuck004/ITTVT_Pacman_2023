﻿namespace PacManWPF.Game.PGs.Enums
{
    public enum GhostColors
    {
        Pink,
        Orange,
        Red,
        Cyan
    }

    public enum GhostTickTypes
    {
        Died = 0,
        Scaried = 1,
        Alive = 2,
    }
}
