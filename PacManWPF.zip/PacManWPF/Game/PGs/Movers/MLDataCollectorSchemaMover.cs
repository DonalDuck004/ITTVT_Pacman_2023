﻿using System.Windows;
using System.Threading;
using System.IO;
using System;
using Microsoft.Data.Sqlite;
using System.Runtime.ConstrainedExecution;
using System.Linq;
using System.Diagnostics;
using System.Collections.Generic;
using Microsoft.Win32.SafeHandles;
using PacManWPF.Utils;
using System.Windows.Shapes;
using System.Numerics;

namespace PacManWPF.Game.PGs.Movers
{
    public class MLDataCollectorSchemaMover : Abs.BaseGhostMover
    {
        private const string ML_DB_NAME = "ml_temp.sqlite";
        private string hash;
        private SqliteConnection connection;
        private System.Drawing.Point Position;
        private System.Drawing.Point? LastPosition = null;
        private static Random rnd = new Random();

        public static Semaphore sem = new Semaphore(1, 1);

        public MLDataCollectorSchemaMover(string hash, System.Drawing.Point start_point)
        {
            try
            {
                sem.WaitOne();
                bool intialize = !File.Exists(ML_DB_NAME);
                connection = new SqliteConnection("Data Source=" + ML_DB_NAME);
                connection.Open();
                this.hash = hash;
                this.Position = start_point;
                if (intialize)
                    this.LoadSchema();
                RegWorld();

            }
            finally
            {
                sem.Release();
            }

        }

        public override System.Drawing.Point GetPos()
        {
            return this.Position;
        }

        private void RegWorld()
        {
            SqliteCommand cur = this.connection.CreateCommand();
            string sql = "INSERT INTO Worlds(WorldName, WorldHash) VALUES($wn, $wh) ON CONFLICT DO NOTHING";
            cur.CommandText = sql;
            cur.Parameters.Clear();
            cur.Parameters.AddWithValue("$wn", "TODO");
            cur.Parameters.AddWithValue("$wh", this.hash);
            cur.ExecuteNonQuery();
        }

        private System.Drawing.Point GetDiffs(System.Drawing.Point pos)
        {
            int x_diff = Math.Abs(Pacman.INSTANCE.Position.X - pos.X);
            int y_diff = Math.Abs(Pacman.INSTANCE.Position.Y - pos.Y);

            return new System.Drawing.Point(x_diff, y_diff);
        }

        record FuturePos(System.Drawing.Point diff, System.Drawing.Point point);

        private System.Drawing.Point FixDest(System.Drawing.Point dest)
        {
            if (dest.X == -1)
                dest.X = Config.CHUNK_WC - 1;
            else if (dest.X == Config.CHUNK_WC)
                dest.X = 0;
            else if (dest.Y == -1)
                dest.Y = Config.CHUNK_HC - 1;
            else if (dest.Y == Config.CHUNK_HC)
                dest.Y = 0;

            return dest;
        }

        private void GetNextPos(List<FuturePos> outlist, int x = 0, int y = 0)
        {
            var dest = new System.Drawing.Point(this.Position.X + x, this.Position.Y + y);
            dest = FixDest(dest);

            var tmp = GetDiffs(dest);
            if (tmp.X + tmp.Y > 10)
                return;

            foreach(var item in PacmanGame.INSTANCE.CeilsAt(dest.X, dest.Y))
                if (item.IsWall())
                    return;

            outlist.Add(new FuturePos(tmp, dest));
        }

        int old_state = 0;

        public override void NextFrame(Ghost self)
        {
            System.Drawing.Point dest;
            
            var possibilities = new List<FuturePos>();
            var tmp = Convert.ToInt32(self.IsDied) + Convert.ToInt32(Pacman.INSTANCE.IsDrugged);

            GetNextPos(possibilities, x: -1);
            GetNextPos(possibilities, x: 1);
            GetNextPos(possibilities, y: -1);
            GetNextPos(possibilities, y: 1);

            if (possibilities.Count == 0)
                return;
            else if (possibilities.Count != 1 && this.old_state == tmp)
            {
                try
                {
                    possibilities.Remove(possibilities.Where(x => x.point == this.LastPosition).First());
                }catch (InvalidOperationException)
                {
                }
            }

            FuturePos[] dests;
            if (Pacman.INSTANCE.IsDrugged)
                dests = possibilities.OrderByDescending(d => d.diff.X + d.diff.Y).ToArray();
            else
                dests = possibilities.OrderBy(d => d.diff.X + d.diff.Y).ToArray();

            if (possibilities.Count > 1)
            {
                if (dests[0].diff.X + dests[0].diff.Y == dests[1].diff.Y + dests[1].diff.X)
                {
                    if (rnd.Next(2) == 0)
                        dest = dests[0].point;
                    else
                        dest = dests[1].point;
                }
                else
                    dest = dests[0].point;
            }
            else
                dest = dests[0].point;


            this.old_state = tmp;
            this.LastPosition = this.Position;
            this.Position = new (dest.X, dest.Y);
        }


        private long? RegPos(SqliteCommand cur, int x, int y, Ghost self, long? previus_id = null, int? flow = null)
        {
            string sql = @"INSERT INTO Positions(ReferToWorld, X, Y, PacmanX, PacmanY, PacmanIsDrugged, PreviusPos, Flow, Ghost) VALUES($wd, $x, $y, $px, $py, $pd, $pi, $f, $gh) RETURNING ID";
            cur.CommandText = sql;
            cur.Parameters.AddWithValue("$wd", this.hash);
            cur.Parameters.AddWithValue("$x", x);
            cur.Parameters.AddWithValue("$y", y);
            cur.Parameters.AddWithValue("$px", Pacman.INSTANCE.Position.X);
            cur.Parameters.AddWithValue("$py", Pacman.INSTANCE.Position.Y);
            cur.Parameters.AddWithValue("$pd", Pacman.INSTANCE.IsDrugged);
            cur.Parameters.AddWithValue("$pi", previus_id is null ? DBNull.Value : previus_id);
            cur.Parameters.AddWithValue("$f", flow is null ? 0 : flow);
            cur.Parameters.AddWithValue("$gh", self.Type);
            SqliteDataReader result = cur.ExecuteReader();
            result.Read();
            object r = result[0];
            result.Close();

            if (r is DBNull)
                return null;
            return (long)r;
        }

        private long? last_id = null;

        private void RegisterPos(int x, int y, int flow, Ghost self)
        {
            sem.WaitOne();

            if (this.last_id is null)
            {
                this.last_id = this.RegPos(this.connection.CreateCommand(), (int)this.Position.X, (int)this.Position.Y, self);
            }

            this.last_id = this.RegPos(this.connection.CreateCommand(), x, y, self, this.last_id, flow);

            sem.Release();

            /*try
            {
                string sql = @"INSERT INTO Positions(ReferToWorld, X, Y, PacmanX, PacmanY, PreviusPos) VALUES($wd, $x, $y, $px, $py, $pp)";
                cur.CommandText = sql;


                sql = "SELECT MAX(ID)"

                Debug.WriteLine(tmp);
            }
            catch
            {

            }*/

        }

        private void LoadSchema()
        {
            string sql = @"CREATE TABLE IF NOT EXISTS Worlds(
                            WorldName VARCHAR(512),
                            WorldHash VARCHAR(32) PRIMARY KEY)";
            SqliteCommand cur = this.connection.CreateCommand();
            cur.CommandText = sql;
            cur.ExecuteNonQuery();


            sql = @"CREATE TABLE IF NOT EXISTS Ghosts(ID INTEGER PRIMARY KEY,
                                                      Color VARCHAR(16))";
            cur.CommandText = sql;
            cur.ExecuteNonQuery();

            sql = @"INSERT INTO Ghosts(ID, Color) VALUES ($0, $1),  ($2, $3),  ($4, $5),  ($6, $7)";

            cur.CommandText = sql;

            var Keys = Enum.GetNames(typeof(Enums.GhostColors));
            var Values = (int[])Enum.GetValues(typeof(Enums.GhostColors));

            int c = 0;
            for (int i = 0; i < Keys.Length; i++)
            {
                cur.Parameters.AddWithValue($"${c++}", Values[i]);
                cur.Parameters.AddWithValue($"${c++}", Keys[i]);
            }

            cur.ExecuteNonQuery();

            sql = @"CREATE TABLE IF NOT EXISTS Positions(ID INTEGER PRIMARY KEY AUTOINCREMENT,
                                                          ReferToWorld REFERENCES Worlds(WorldHash),
                                                          X INT NOT NULL, 
                                                          Y INT NOT NULL,
                                                          PacmanX INT NOT NULL, 
                                                          PacmanY INT NOT NULL, 
                                                          PacmanIsDrugged INT NOT NULL, 
                                                          flow INT,
                                                          Ghost REFERENCES Ghosts(ID), 
                                                          PreviusPos REFERENCES Positions(ID))";
            cur.CommandText = sql;
            cur.ExecuteNonQuery();
        }
    }
}
