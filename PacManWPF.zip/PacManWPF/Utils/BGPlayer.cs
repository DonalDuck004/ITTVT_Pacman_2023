﻿using System;
using System.Media;

namespace PacManWPF.Utils
{
    public static class SoundEffectsPlayer
    {
        public static string CHOMP = "Sounds/chomp.wav";
        public static string START = "Sounds/start.wav";

        private static SoundPlayer soundPlayer = new SoundPlayer();

        static SoundEffectsPlayer()
        {
            soundPlayer.LoadCompleted += _Play;
        }

        private static void _Play(object? sender, EventArgs e)
        {
            soundPlayer.Stop();
            soundPlayer.Play();
        }

        public static void Play(string track)
        {
            soundPlayer.SoundLocation = track;
            soundPlayer.LoadAsync();
        }
    }
}
