﻿using System.Windows.Media;
using System.Windows.Shapes;


namespace PacManWPF.Game.PGs.Movers
{
    internal class Restorer
    {
        public required Ghost ghost;
        public required Rectangle GameCeil;
        public required ImageBrush? Image;
        public required bool Died;

        public bool Used = false;
    }
}
