﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using PacManWPF.Utils;

namespace PacManWPF.Game.PGs
{

    public class Pacman : Abs.BasePG
    {
#nullable disable
        public static Pacman INSTANCE;
#nullable restore

        public int X { get; private set; }
        public int Y { get; private set; }
        public int Grad { get; private set; }
        private int animation_count;

        public override System.Drawing.Point Position { get => new System.Drawing.Point(X, Y); }

        private WrapPanel drug_wrap;
        private Label drug_ticks_label;
        private Label points_label;

        private int _drug_frames = 0;
        public int DrugTicks
        {
            get => _drug_frames;
            set
            {
                if (value == 0)
                    drug_wrap.Visibility = Visibility.Hidden;
                else
                {
                    drug_wrap.Visibility = Visibility.Visible;

                    drug_ticks_label.Content = value.ToString().ZFill(2) + " ticks";
                }

                _drug_frames = value; // + 100;
            }
        }

        private int _points = 0;
        public int Points
        {
            get
            {
                return _points;
            }
            set
            {
                points_label.Content = value.ToString().ZFill(3);
                _points = value;
            }
        }

        public bool IsDrugged
        {
            get => DrugTicks > 0;
        }

        public Rectangle EffectiveCeil
        {
            get => MainWindow.game_ceils.CeilAt(X, Y);
        }

        public Pacman(MainWindow app)
        {
            drug_wrap = app.drug_wrap;
            drug_ticks_label = app.drug_ticks_label;
            points_label = app.points_label;
            INSTANCE = this;
        }

        public void Initialize(int x, int y, int grad)
        {
            IsDied = false;
            DrugTicks = 0;
            Points = 0;
            X = x;
            Y = y;
            Grad = grad;

            var img = GetImage();
            img.RelativeTransform = GetTransform();
            EffectiveCeil.Fill = img;
        }


        public MatrixTransform GetTransform(int? grad = null)
        {
            var transform = Matrix.Identity;
            transform.RotateAt(grad ?? Grad, 0.5, 0.5);

            if (IsDrugged)
            {
                transform.ScaleAt(2, 2, 0.5, 0.5);
            }
            else
            {
                transform.ScaleAt(1, 1, 0.5, 0.5);
            }

            return new MatrixTransform(transform);
        }

        public ImageBrush GetImage() => ResourcesLoader.GetImage(ResourcesLoader.PacManAnimationPaths[++animation_count % 3]);

        public void MoveTo(int x, int y, int grad)
        {
            if (x == -1)
                x = Config.CHUNK_WC - 1;
            else if (x == Config.CHUNK_WC)
                x = 0;

            if (y == -1)
                y = Config.CHUNK_HC - 1;
            else if (y == Config.CHUNK_HC)
                y = 0;

            Rectangle dest_ceil = MainWindow.game_ceils.CeilAt(x, y);


            bool is_not_wall = false;

            if (dest_ceil.IsPoint())
            {
                SoundEffectsPlayer.Play(SoundEffectsPlayer.CHOMP);
                Points++;
            }
            else if (dest_ceil.IsDrug())
                DrugTicks += Config.DRUG_TICKS;
            else if (dest_ceil.Fill is not null)
            {
                foreach (Ghost killer in Ghost.INSTANCES)
                {
                    if (y == killer.Position.Y && x == killer.Position.X) // && !killer.IsDied)
                    {
                        if (IsDrugged || killer.IsDied)
                            killer.Kill(new Point(x, y));
                        else
                        {
                            IsDied = true;
                            break;
                        }
                    }
                }

                if (!(dest_ceil.IsScariedGhost() || dest_ceil.IsDiedGhost()))
                {
                    dest_ceil = MainWindow.game_ceils.CeilAt(X, Y);
                    is_not_wall = true;
                }


            }

            if (!is_not_wall)
            {
                EffectiveCeil.Fill = null;
                X = x;
                Y = y;
            }

            Grad = grad;
            var img = GetImage(); // Without this var, it may result laggy
            img.RelativeTransform = GetTransform(grad);
            dest_ceil.Fill = img;
        }

        public bool IsAt(System.Drawing.Point point) => IsAt((int)point.X, (int)point.Y);

        public bool IsAt(int x, int y) => x == X && y == Y;

    }
}
