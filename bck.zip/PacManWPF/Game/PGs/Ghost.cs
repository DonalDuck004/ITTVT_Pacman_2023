﻿using System.Collections.Generic;
using System.Windows.Media;
using System;
using System.Windows;
using System.Windows.Shapes;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Diagnostics;
using System.Windows.Media.Imaging;
using System.Runtime.CompilerServices;
using System.Windows.Controls;
using PacManWPF.Game.PGs.Enums;
using PacManWPF.Utils;
using PacManWPF.Game;
using PacManWPF.Game.PGs.Movers.Abs;
using PacManWPF.Game.PGs.Movers;

namespace PacManWPF.Game.PGs
{

    public class Ghost : PacManWPF.Game.Abs.BasePG
    {
        // public ImageBrush? reset_ceil = null;
        public ImageBrush Image;

        public GhostColors Type { get; private set; }
        private BaseGhostMover mover;
        private Pacman Pacman;

        private bool initialized = false;

        public static Ghost[] INSTANCES = new Ghost[4];
        public static Ghost CyanGhost { get => Ghost.INSTANCES[0]; }
        public static Ghost PinkGhost { get => Ghost.INSTANCES[1]; }
        public static Ghost RedGhost { get => Ghost.INSTANCES[2]; }
        public static Ghost OrangeGhost { get => Ghost.INSTANCES[3]; }


        public override System.Drawing.Point Position
        {
            get
            {
                if (!initialized) throw new Exception($"SetSchema for ghost {Type} not called!");

                return mover.GetPos();
            }
        }

        public Rectangle EffectiveGameCeil
        {
            get => MainWindow.game_ceils.CeilAt(Position);
        }

#pragma warning disable CS8618 
        public Ghost(GhostColors type)
#pragma warning restore CS8618
        {
            Type = type;
            Image = ResourcesLoader.GetImage(type is GhostColors.Cyan ? ResourcesLoader.CyanGhost :
                                              type is GhostColors.Pink ? ResourcesLoader.PinkGhost :
                                              type is GhostColors.Red ? ResourcesLoader.RedGhost : ResourcesLoader.OrangeGhost);
            if (Pacman.INSTANCE is null)
                throw new Exception("Pacman not instantiated");

            Pacman = Pacman.INSTANCE;
        }

        public bool ShouldTick(GhostTickTypes tickType)
        {

            if (IsDied && tickType is GhostTickTypes.Died)
                return true;
            else if (Pacman.IsDrugged && tickType is GhostTickTypes.Scaried)
                return true;
            else if (!IsDied && !Pacman.IsDrugged && tickType is GhostTickTypes.Alive)
                return true;
            return false;
        }

        public void SetSchema(BaseGhostMover mover)
        {
            initialized = true;
            this.mover = mover;

            ImageBrush? reset_ceil = (ImageBrush?)EffectiveGameCeil.Fill;
            EffectiveGameCeil.Fill = Image;

            IsDied = false;
            stack_placer.Add(new Restorer()
            {
                ghost = this,
                GameCeil = EffectiveGameCeil,
                Image = reset_ceil,
                Died = IsDied,
            }
            );
        }

        public void Kill(Point? pacman_pos = null)
        {
            IsDied = true; // If I will change it with a property as readonly
            // Ad replace it with a counter
            // Add another parameter here, in order to avoid, problem, becausa this function
            // maybe be recalled from Pacman class when the ghost is died
            if (pacman_pos is not null)
            {
                return;
                foreach (var tmp in stack_placer.Reverse<Restorer>())
                {
                    if (Grid.GetColumn(tmp.GameCeil) == pacman_pos.Value.X && Grid.GetRow(tmp.GameCeil) == pacman_pos.Value.Y)
                    {
                        if (tmp.Image.IsDrug())
                        {
                            Pacman.DrugTicks += Config.DRUG_TICKS;
                            tmp.Image = null;
                        }
                        else if (tmp.Image.IsPoint())
                        {
                            Pacman.Points++;
                            tmp.Image = null;
                        }
                        return;
                    }

                }
            }
        }

        private static List<Restorer> stack_placer = new List<Restorer>();
        public static void ClearMover() => stack_placer.Clear();
        public static void BeginTick(GhostTickTypes type)
        {
            return;
            Restorer item;
            int c = stack_placer.Count;
            bool last_ok = true;
            Restorer? last = null;

            for (int i = c - 1; i >= 0; i--)
            {
                item = stack_placer[i];
                if (!item.ghost.ShouldTick(type))
                {
                    last = item;
                    last_ok = false;
                    continue;
                }

#pragma warning disable CS8602
                if (last_ok is false)
                {
                    last_ok = true;
                    // TODO if (last.Image.IsGhost)
                    last.Image = null;
                }
#pragma warning restore CS8602

                item.Used = true;
                stack_placer.RemoveAt(i);
                if (item.ghost.Pacman.IsAt(item.ghost.Position))
                {
                    if (item.ghost.IsDied)
                        continue;

                    if (item.ghost.Pacman.IsDrugged)
                    {
                        item.ghost.Kill();
                    }
                    else
                    {
                        item.GameCeil.Fill = item.ghost.Image;
                        item.ghost.Pacman.IsDied = true;
                    }

                }
                else
                {
                    item.GameCeil.Fill = item.Image;
                }
            }
        }


        public void Tick()
        {

            if (!initialized)
                throw new Exception($"SetSchema for ghost {Type} not called!");

            mover.NextFrame(this);



            /*bool IsPacman = EffectiveGameCeil.IsPacman();
            ImageBrush? reset_ceil = IsPacman ? null : (ImageBrush?)EffectiveGameCeil.Fill;
            if (!(IsPacman && IsDied))
            {
                EffectiveGameCeil.Fill = IsDied ? ResourcesLoader.GhostEyes : Pacman.IsDrugged ? ResourcesLoader.ScaryGhost : Image;
            }
            stack_placer.Add(new Restorer()
            {
                ghost = this,
                GameCeil = EffectiveGameCeil,
                Image = reset_ceil,
                Died = IsDied,
            });*/
        }

    }
}
