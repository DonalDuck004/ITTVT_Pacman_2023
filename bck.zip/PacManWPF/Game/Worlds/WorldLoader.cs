﻿using System.IO;
using System.Collections.Generic;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using System;
using PacManWPF.Utils;
using PacManWPF.Game.PGs;
using PacManWPF.Game.PGs.Movers;
using PacManWPF.Game.PGs.Movers.Abs;
using System.Security.Cryptography;
using System.Drawing;

namespace PacManWPF.Game.Worlds
{

    class World
    {
        private string filename;
        public string name;

        public World(string file)
        {
            filename = file;

            name = Path.GetFileName(file).Split(".")[0];
        }

        private IEnumerable<ImageBrush?> ParseChunks()
        {
            using (BinaryReader sr = new BinaryReader(new FileStream(filename, FileMode.Open, FileAccess.Read)))
            {

                int v;

                while (sr.BaseStream.Position != sr.BaseStream.Length)
                {
                    v = sr.ReadInt32();

                    if (v == -1)
                        yield return null;
                    else
                        yield return ResourcesLoader.GetImage(ResourcesLoader.Paths[v]);
                }
            }
        }

        public void Apply(MainWindow app)
        {
            SoundEffectsPlayer.Play(SoundEffectsPlayer.START);
            // background.SuspendLayout();
            int v;
            app.total_points = 0;
            app.Pacman.Points = 0;
            //Chunk tmp;

            // background.Size = new Size(Config.CHUNK_WC * Config.ChunkSquare, Config.CHUNK_HC * Config.ChunkSquare);
            using (BinaryReader sr = new BinaryReader(new FileStream(filename, FileMode.Open, FileAccess.Read)))
            {

                app.Pacman.Initialize(sr.ReadInt32(), sr.ReadInt32(), sr.ReadInt32() * 90);
                byte[] md5 = new byte[Config.CHUNK_HC * Config.CHUNK_WC * 4];
                int idx = 0;

                for (int y = 0; y < Config.CHUNK_HC; y++)
                {
                    for (int x = 0; x < Config.CHUNK_WC; x++)
                    {
                        v = sr.ReadInt32();
                        BitConverter.GetBytes(v).CopyTo(md5, idx);
                        idx += 4;

                        if (app.Pacman.IsAt(x, y))
                            continue;

                        if (v == -1)
                        {
                            MainWindow.game_ceils[y][x].Fill = ResourcesLoader.SmallPoint;
                            app.total_points++;
                        }
                        else if (v == -2)
                            MainWindow.game_ceils[y][x].Fill = ResourcesLoader.Drug;
                        else if (v == -3)
                            MainWindow.game_ceils[y][x].Fill = null;
                        else
                            MainWindow.game_ceils[y][x].Fill = ResourcesLoader.GetImage(ResourcesLoader.Paths[v]);
                    }

                }

                md5 = MD5.Create().ComputeHash(md5);

                Type schema_type;
                foreach (Ghost ghost in Ghost.INSTANCES)
                {
                    switch (sr.ReadInt32())
                    {
                        case 1:
                            schema_type = typeof(NextToBackSchemaMover);
                            break;
                        case 2:
                            schema_type = typeof(CyclicSchemaMover);
                            break;
                        case 3:
                            schema_type = typeof(MLDataCollectorSchemaMover);
                            break;
                        default: 
                            throw new Exception();
                    }

#pragma warning disable CS8604
#pragma warning disable CS8600
                    if (schema_type.IsSubclassOf(typeof(SchemaBasedMover)))
                    {
                        Point[] schema = new Point[sr.ReadInt32()];
                        for (int i = 0; i < schema.Length; i++)
                            schema[i] = new Point(sr.ReadInt32(), sr.ReadInt32());
                        ghost.SetSchema((BaseGhostMover)Activator.CreateInstance(schema_type, schema));
                    } else if (schema_type == typeof(MLDataCollectorSchemaMover))
                    {
                        ghost.SetSchema((BaseGhostMover)Activator.CreateInstance(schema_type, 
                                                                                 Convert.ToHexString(md5), 
                                                                                 new Point(sr.ReadInt32(), sr.ReadInt32())));
                    }
#pragma warning restore CS8604
#pragma warning restore CS8600

                }

            }
        }
    }

    static class WorldLoader
    {
        private static List<World>? _cache = null;

        public static List<World> Worlds
        {
            get
            {
                if (_cache is null)
                {
                    _cache = new List<World>();

                    foreach (string file in Directory.GetFiles(Config.WORLD_DIR))
                        _cache.Add(new World(file));

                }

                return _cache;
            }
        }

        public static void DropCache()
        {
            _cache = null;
        }

    }
}
