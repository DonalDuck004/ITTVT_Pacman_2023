﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices.JavaScript;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using PacManWPF.Game.Worlds;
using PacManWPF.Game.PGs;
using PacManWPF.Game.PGs.Enums;
using PacManWPF.Utils;

namespace PacManWPF
{

    public partial class MainWindow : Window
    {
        public int total_points;
        private bool is_frozen = false;

        public Pacman Pacman;

#nullable disable
        public static Rectangle[][] game_ceils;
#nullable restore

        private Semaphore mutex = new Semaphore(1, 1);

        private DateTime start_time;
        
        private DateTime last_call = DateTime.Now;

        private DispatcherTimer game_ticker = new DispatcherTimer(DispatcherPriority.Input)
        {
            Interval = new TimeSpan(TimeSpan.TicksPerSecond / 8),

        };


        public MainWindow()
        {
            InitializeComponent();
            this.AdaptToSize();
            MainWindow.game_ceils = this.game_grid.Children.OfType<Rectangle>().Split(Config.CHUNK_WC).ToArray();
            this.game_ticker.Tick += new EventHandler(OnGameTick);
            this.Pacman = new Pacman(this);
            Ghost.INSTANCES[0] = new(GhostColors.Cyan);
            Ghost.INSTANCES[1] = new(GhostColors.Pink);
            Ghost.INSTANCES[2] = new(GhostColors.Red);
            Ghost.INSTANCES[3] = new(GhostColors.Orange);



            Random rnd = new Random();

            foreach (var row in MainWindow.game_ceils)
            {
                foreach (var col in row)
                    col.Fill = ResourcesLoader.GetImage(ResourcesLoader.Paths[rnd.Next(ResourcesLoader.Paths.Length)]);
            }
        }
       
        public void DispatchKey(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            if (e.Key is Key.Escape)
            {
                if (this.pause_menu.IsSelected)
                {
                    this.ResumeGame();
                    this.game_tab.IsSelected = true;
                }
                else
                {
                    this.FreezeGame();
                    this.app_pages.SelectedIndex = this.pause_menu.TabIndex;
                }
                CloseMenu();
                return;
            }

            int dest_x = this.Pacman.X;
            int dest_y = this.Pacman.Y;
            int angular;

            if (e.Key is Key.Right)
            {
                dest_x++;
                angular = 0;
            }
            else if (e.Key is Key.Left)
            {
                dest_x--;
                angular = 180;
            }
            else if (e.Key is Key.Up)
            {
                dest_y--;
                angular = 270;
            }
            else if (e.Key is Key.Down)
            {
                dest_y++;
                angular = 90;
            }
            else
            {
                e.Handled = false;
                return;
            }

            if (this.is_frozen)
                return;

            if (!this.Pacman.IsDrugged && DateTime.Now - this.last_call < new TimeSpan(TimeSpan.TicksPerSecond / 10))
                return;

            this.last_call = DateTime.Now;

            try
            {
                this.mutex.WaitOne();
                this.Pacman.MoveTo(dest_x, dest_y, angular);
                if (this.Pacman.IsDied)
                    this.GameOver(set_img_to_null: true);
            }
            finally
            {
                this.mutex.Release();
            }
            
        }

        public void ClosePauseMenu(object sender, EventArgs e)
        {
            this.game_tab.IsSelected = true;
            CloseMenu();
        }

        public void CloseMenu()
        {
            if (this.pause_menu.IsSelected)
            {
                foreach (World world in WorldLoader.Worlds)
                    this.worlds_box.Items.Add(world.name);
            }
            else
            {
                this.worlds_box.Items.Clear();
                this.ResumeGame();
            }

        }

        // 1 yes one 

        GhostTickTypes faster_tick_lvl = GhostTickTypes.Scaried;

        private void OnGameTick(object? sender, EventArgs e)
        {
            if (this.is_frozen)
                return;


            this.mutex.WaitOne();
            if (!this.game_ticker.IsEnabled)
                return;

            try
            {
                bool was_drugged = this.Pacman.IsDrugged;
                if (was_drugged)
                    this.Pacman.DrugTicks--;

                this.faster_tick_lvl = (GhostTickTypes)(((int)faster_tick_lvl + 1) % 3);
                Debug.WriteLine(this.faster_tick_lvl);
                bool begin_called = false;

                for (int i = 0; i < Ghost.INSTANCES.Length; i++)
                {
                    if (Ghost.INSTANCES[i].ShouldTick(this.faster_tick_lvl))
                    {
                        if (begin_called is false)
                        {
                            Ghost.BeginTick(faster_tick_lvl);
                            begin_called = true;
                        }
                        Ghost.INSTANCES[i].Tick();

                        if (this.Pacman.IsDied)
                        {
                            // this.faster_tick_lvl = (GhostTickTypes)(((int)faster_tick_lvl + 1) % 3);
                            // Ghost.BeginTick(faster_tick_lvl);
                            this.GameOver();
                            return;
                        }
                    }
                }


                if (faster_tick_lvl is not GhostTickTypes.Died)
                {
                    this.Pacman.EffectiveCeil.Fill = this.Pacman.GetImage();
                    this.Pacman.EffectiveCeil.Fill.RelativeTransform = this.Pacman.GetTransform();
                }


                if (this.Pacman.Points == this.total_points && !this.Pacman.IsDied)
                    this.Won(in_safe_context: true);

            }
            finally
            {
                this.mutex.Release();
            }
        }

        public void Won(bool in_safe_context)
        {
            // (new Thread(() => MessageBox.Show("You won"))).Start();
            var tmp = this.Pacman.EffectiveCeil.Fill.RelativeTransform;
            this.Pacman.EffectiveCeil.Fill = ResourcesLoader.PacMan;
            this.Pacman.EffectiveCeil.Fill.RelativeTransform = tmp;
            this.FreezeGame();

            this.ellapsed_time_label.Content = (new DateTime((DateTime.Now - this.start_time).Ticks)).ToString("HH:mm:ss");
            this.game_won_tab.IsSelected = true;
        }

        public void GameOver(bool set_img_to_null = false)
        {
            this.FreezeGame();
            this.Pacman.IsDied = true;
            if (set_img_to_null)
                this.Pacman.EffectiveCeil.Fill = null;


            this.UpdateLayout();
            MessageBox.Show("Game Over");
        }

        private void FreezeGame()
        {
            if (this.game_ticker.IsEnabled)
                this.game_ticker.Stop();

            this.is_frozen = true;
        }


        private void ResumeGame()
        {
            if (!this.game_ticker.IsEnabled)
                this.game_ticker.Start();
            this.is_frozen = false;
        }


        private void OnWorldSelected(object sender, SelectionChangedEventArgs e)
        {
            if (this.worlds_box.SelectedIndex == -1) 
                return;

            this.mutex.WaitOne();
            FreezeGame();
            this.world_label.Content = WorldLoader.Worlds[this.worlds_box.SelectedIndex].name;
            this.game_won_label.Content = this.world_label.Content;
            Ghost.ClearMover();
            WorldLoader.Worlds[this.worlds_box.SelectedIndex].Apply(this);
            this.game_tab.IsSelected = true;
            this.CloseMenu();
            this.start_time = DateTime.Now;
            GC.Collect();
            this.mutex.Release();
        }

    }
}
