﻿using System;
using System.Windows.Media;
using System.Collections.Generic;
using System.Windows.Media.Imaging;

namespace PacManWPF.Utils
{
    enum Walls
    {
        TopLine =    0b0001,
        LeftLine =   0b0010,
        BottomLine = 0b0100,
        RightLine =  0b1000,
    }

    enum Rotation
    {
        Grad0 =   0b0001,
        Grad90 =  0b0010,
        Grad180 = 0b0100,
        Grad270 = 0b1000
    }

    static class ResourcesLoader
    {
        public const string BottomFullExtended = @"Images\BottomFullExtended.png";
        public const string BottomLeftAndTopRightCurve = @"Images\BottomLeftAndTopRightCurve.png";
        public const string BottomRightCurve = @"Images\BottomRightCurve.png";
        public const string BottomToRight = @"Images\BottomToRight.png";
        public const string LeftBottomCurve = @"Images\LeftBottomCurve.png";
        public const string LeftFullExtended = @"Images\LeftFullExtended.png";
        public const string LeftToBottom = @"Images\LeftToBottom.png";
        public const string LeftTopAndRightBottomCurve = @"Images\LeftTopAndRightBottomCurve.png";
        public const string LeftTopCurve = @"Images\LeftTopCurve.png";
        public const string LeftToTop = @"Images\LeftToTop.png";
        public const string SelfRight = @"Images\SelfRight.png";
        public const string SelfLeft = @"Images\SelfLeft.png";
        public const string SelfTop = @"Images\SelfTop.png";
        public const string SelfBottom = @"Images\SelfBottom.png";
        public const string RightFullExtended = @"Images\RightFullExtended.png";
        public const string RightTopCurve = @"Images\RightTopCurve.png";
        public const string TopFullExtended = @"Images\TopFullExtended.png";
        public const string TopToRight = @"Images\TopToRight.png";
        public const string CyanGhost = @"Images\cyan.png";
        public const string PinkGhost = @"Images\pink.png";
        public const string RedGhost = @"Images\red.png";
        public const string OrangeGhost = @"Images\orange.png";

        public const string GHOST_EYES_PATH = @"Images\eyes.png";
        public const string DRUG_PATH = @"Images\Drug.png";
        public const string PACMAN_PATH = @"Images\pacman_open.png";
        public const string PACMAN_P_CLOSED_PATH = @"Images\pacman_partially_closed.png";
        public const string PACMAN_CLOSED_PATH = @"Images\pacman_closed.png";
        public const string SMALL_POINT_PATH = @"Images\Point.png";
        public const string SCARY_GHOST_PATH = @"Images\dead_ghost.png";


        public static string[] PacManAnimationPaths = { PACMAN_PATH, PACMAN_P_CLOSED_PATH, PACMAN_CLOSED_PATH };

        public static string[] Paths = {BottomFullExtended, BottomLeftAndTopRightCurve, BottomRightCurve, BottomToRight,
                                        LeftBottomCurve, LeftFullExtended, LeftToBottom, LeftTopAndRightBottomCurve,
                                        LeftTopCurve, LeftToTop, RightFullExtended, RightTopCurve,
                                        SelfBottom, SelfLeft, SelfRight, SelfTop, TopFullExtended, TopToRight};


        private static Dictionary<string, ImageBrush> cache = new();

        public static ImageBrush GhostEyes
        {
            get => GetImage(GHOST_EYES_PATH);

        }

        public static ImageBrush PacMan
        {
            get => GetImage(PACMAN_PATH);
        }
        // static Random rnd = new Random();

        public static ImageBrush ScaryGhost
        {
            get => GetImage(SCARY_GHOST_PATH); // Paths[rnd.Next(Paths.Length)]);
        }

        public static ImageBrush SmallPoint
        {
            get => GetImage(SMALL_POINT_PATH);
        }

        public static ImageBrush Drug
        {
            get => GetImage(DRUG_PATH);
        }

        public static ImageBrush GetImage(string name)
        {
            if (!cache.ContainsKey(name))
                cache[name] = new ImageBrush()
                {
                    ImageSource = new BitmapImage(new Uri(name, UriKind.Relative)),
                };

            return cache[name];
        }
    }
}
